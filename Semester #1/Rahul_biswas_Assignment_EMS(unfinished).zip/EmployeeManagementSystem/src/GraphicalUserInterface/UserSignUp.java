package GraphicalUserInterface;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class UserSignUp implements ActionListener{
	//Basic requirements
	private JFrame window = new JFrame();
	private String title = "Login";
	private final int height = 250;
	private final int width = 200;
	private int scale = 2;
	
	//North Panel
	private JPanel north = new JPanel();
	JLabel login = new JLabel("Login Form");
	
	//Center Panel
	private JPanel center = new JPanel();
	private JLabel usernameLabel = new JLabel("Username :");
	private JLabel passwordLabel = new JLabel("Password :");
	private JTextField usernameTextField = new JTextField(25);
	private JTextField passwordTextField = new JTextField(25);
	private JLabel emailIdLabel = new JLabel("EmailID :");
	private JTextField emailIdTextField = new JTextField(25);
	private JButton signupButton = new JButton("Sign up");
	
	
	private UserLogin userLoginWindow; 
	public UserSignUp(UserLogin userLoginWindow)
	{
	//	northPanel();
	//	centerPanel();
	//	southPanel();
		this.userLoginWindow = userLoginWindow;
		initWindow();
		window.setVisible(true);
	}
	private void initWindow()
	{
		window.setTitle(title);
		window.setSize(new Dimension(width*scale,height*scale));
		window.setPreferredSize(new Dimension(width*scale,height*scale));
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setResizable(false);
	//	window.setLayout(null);;
		window.pack();
		window.setLocationRelativeTo(null);
		signupButton.addActionListener(this);
		window.add(signupButton,BorderLayout.SOUTH);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equalsIgnoreCase("Sign up"))
		{
			System.out.println("Signup");
			userLoginWindow.makeVisible();
			window.dispose();

	
		}
		
	}
}
