package MainPackage;
import GraphicalUserInterface.*;
public class MainClass {

	public static void main(String[] args) {
	
		new UserLogin();
	}

}
