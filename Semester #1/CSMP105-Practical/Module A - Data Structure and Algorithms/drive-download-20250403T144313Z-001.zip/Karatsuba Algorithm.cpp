#include <stdio.h>
#include <math.h>

// Function to calculate the number of digits in a number
int numDigits(int n) {
    int count = 0;
    while (n > 0) {
        count++;
        n /= 10;
    }
    return count;
}

// Karatsuba multiplication function
long long karatsuba(int x, int y) {
    if (x < 10 || y < 10) return x * y;

    int n = fmax(numDigits(x), numDigits(y));
    int m = n / 2;

    int power = pow(10, m);
    int a = x / power;
    int b = x % power;
    int c = y / power;
    int d = y % power;

    long long ac = karatsuba(a, c);
    long long bd = karatsuba(b, d);
    long long ad_plus_bc = karatsuba(a + b, c + d) - ac - bd;

    return ac * pow(10, 2 * m) + ad_plus_bc * pow(10, m) + bd;
}

int main() {
    int num1, num2;
    printf("Enter first number: ");
    scanf("%d", &num1);
    printf("Enter Second number: ");
    scanf("%d", &num2);
    
    printf("Product using Karatsuba Algorithm: %lld\n", karatsuba(num1, num2));
    return 0;
}


/*Steps:
Base Case: If x or y is a single-digit number, return x * y.

Calculate n: Find the maximum number of digits in x and y.

Split the numbers:

Divide x into a (left half) and b (right half).

Divide y into c (left half) and d (right half).

Recursively compute:

Compute ac = Karatsuba(a, c).

Compute bd = Karatsuba(b, d).

Compute ad_plus_bc = Karatsuba(a + b, c + d) - ac - bd.

Combine the results:

Compute the final result using the formula: ac * pow(10, 2 * m) + ad_plus_bc * pow(10, m) + bd

Return the result.



1. Karatsuba's Algorithm for Multiplication
Karatsuba's multiplication reduces the number of recursive multiplications compared to the standard method. The recurrence relation for Karatsuba's algorithm is:
T(n) = 3T(n/2) + O(n)
Using the Master Theorem for recurrence relations of the form:
T(n) = aT(n/b) + O(nd)
where a = 3, b = 2, and d = 1, we compared with log, a = log2 3 � 1.585. Since d < log, a, the complexity is determined by O(nlog2 3).
T(n) = O(nlog23) � O(n1.585)
Comparison with Standard Multiplication
�
Standard Multiplication: O(n2)
�
Karatsuba's Multiplication: O(n1.585) */

