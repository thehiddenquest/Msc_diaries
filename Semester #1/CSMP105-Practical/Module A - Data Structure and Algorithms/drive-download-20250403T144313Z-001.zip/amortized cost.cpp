#include <stdio.h>
#include <math.h>

int main() {
    int num[20], ti[50], ci[50], ai[50];
    int n, i, j, c, p;
    
    printf("Enter the number of digits: ");
    scanf("%d", &n);

    // Initialize num array with 0
    for (i = 0; i < n; i++)
        num[i] = 0;

    printf("\nNumber \t ti \t ci \t ai\n");
    printf("----------------------------\n");

    c = 1;
    ci[0] = 0;  // Initial count of ones
    p = (int)pow(2, n); // Total iterations

    while (c <= p) {
        ti[c] = 0;
        ci[c] = 0;
        ai[c] = 0;

        i = n - 1;

        // Generate next binary sequence
        while (i >= 0) {
            if (num[i] == 1) {
                num[i] = 0;
                ti[c]++; // Count transitions
            } else {
                num[i] = 1;
                ti[c]++;
                break;
            }
            i--;    
        }

        // Print binary number and calculate ci and ai
        for (j = 0; j < n; j++) {
            printf("%d", num[j]);
            if (num[j] == 1)
                ci[c]++;
        }

        ai[c] = ti[c] + ci[c] - ci[c - 1]; // Compute amortized cost
        printf("\t %d \t %d \t %d\n", ti[c], ci[c], ai[c]);
        c++;
    }

    return 0;
}


/* Step 1: Initialize Arrays
Create three arrays:

num[] ? Stores binary numbers.

ti[] ? Stores transition counts.

ci[] ? Stores the count of 1s in each binary number.

ai[] ? Stores amortized cost.

Step 2: Read Input
Take n as input (number of binary digits).

Step 3: Initialize First Binary Number
Start with 000...0 (all bits set to 0).

Step 4: Iterate Over All 2^n Numbers
Loop from 1 to 2^n:

Update Binary Number (by flipping bits from right to left).

Compute Transition Count (ti[c]):

Count the number of bits flipped.

Compute 1s Count (ci[c]):

Count the number of 1s in the binary number.

Compute Amortized Cost (ai[c]):

Using the formula ai[c] = ti[c] + ci[c] - ci[c-1].

Print the Results*/
