#include <stdio.h>
#include <stdlib.h>

#define MAX 1000  // Maximum number of nodes

// **Graph structure using adjacency list**
typedef struct Node {
    int vertex;
    struct Node* next;
} Node;

Node* adj[MAX];  // Adjacency list for directed graph
int dfn[MAX], low[MAX], onStack[MAX], stack[MAX], top = -1;
int timeStamp = 0, n, m;

// **Function to add a directed edge**
void addEdge(int u, int v) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->vertex = v;
    newNode->next = adj[u];
    adj[u] = newNode;
}

// **Recursive DFS Function for SCC using Tarjan's Algorithm**
void dfs(int u) {
    dfn[u] = low[u] = ++timeStamp;
    stack[++top] = u; // Push to stack
    onStack[u] = 1;

    Node* temp = adj[u];
    while (temp) {
        int v = temp->vertex;
        if (dfn[v] == 0) { // If v is not visited
            dfs(v);
            low[u] = (low[u] < low[v]) ? low[u] : low[v];
        } else if (onStack[v]) { // Back edge (part of SCC)
            low[u] = (low[u] < dfn[v]) ? low[u] : dfn[v];
        }
        temp = temp->next;
    }

    // **If u is the root of an SCC**
    if (low[u] == dfn[u]) {
        printf("\nSCC: ");
        int w;
        do {
            w = stack[top--];
            onStack[w] = 0;
            printf("%d ", w);
        } while (w != u);
        printf("\n");
    }
}

// **Display Adjacency List**
void printGraph() {
    printf("\nAdjacency List (Directed Graph):\n");
    for (int i = 1; i <= n; i++) {
        printf("[%d] -> ", i);
        Node* temp = adj[i];
        while (temp) {
            printf("%d -> ", temp->vertex);
            temp = temp->next;
        }
        printf("NULL\n");
    }
}

// **Main Function**
int main() {
    printf("Enter number of vertices: ");
    scanf("%d", &n);
    printf("Enter number of edges: ");
    scanf("%d", &m);

    printf("Enter directed edges (format: u v):\n");
    for (int i = 0; i < m; i++) {
        int u, v;
        scanf("%d %d", &u, &v);
        addEdge(u, v); // **Directed edge**
    }

    printGraph();

    // **Initialize and run DFS for SCCs**
    for (int i = 1; i <= n; i++) {
        if (dfn[i] == 0) {
            dfs(i);
        }
    }

    return 0;
}

