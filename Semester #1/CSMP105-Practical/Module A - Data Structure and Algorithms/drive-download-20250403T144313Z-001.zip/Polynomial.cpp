#include <stdio.h>

// Function to add two polynomials
void addPolynomials(int degreeA, int A[], int degreeB, int B[]) {
    int maxDegree = degreeA;
    if (degreeB > degreeA) {
        maxDegree = degreeB;
    }

    int C[maxDegree + 1];

    for (int i = 0; i <= maxDegree; i++) {
        int coeffA = (i <= degreeA) ? A[i] : 0;
        int coeffB = (i <= degreeB) ? B[i] : 0;
        C[i] = coeffA + coeffB;
    }

    printf("Sum of polynomials: ");
    for (int i = maxDegree; i >= 0; i--) {
        printf("%d(x^%d) ", C[i], i);
        if (i > 0) printf("+ ");
    }
    printf("\n");
}

// Function to subtract polynomial B from A
void subtractPolynomials(int degreeA, int A[], int degreeB, int B[]) {
    int maxDegree = degreeA;
    if (degreeB > degreeA) {
        maxDegree = degreeB;
    }

    int C[maxDegree + 1];

    for (int i = 0; i <= maxDegree; i++) {
        int coeffA = (i <= degreeA) ? A[i] : 0;
        int coeffB = (i <= degreeB) ? B[i] : 0;
        C[i] = coeffA - coeffB;
    }

    printf("Difference of polynomials: ");
    for (int i = maxDegree; i >= 0; i--) {
        printf("%d(x^%d) ", C[i], i);
        if (i > 0) printf("+ ");
    }
    printf("\n");
}

// Function to multiply two polynomials
void multiplyPolynomials(int degreeA, int A[], int degreeB, int B[]) {
    int degreeC = degreeA + degreeB;
    int C[degreeC + 1];

    for (int i = 0; i <= degreeC; i++) {
        C[i] = 0;
    }

    for (int i = 0; i <= degreeA; i++) {
        for (int j = 0; j <= degreeB; j++) {
            C[i + j] += A[i] * B[j];
        }
    }

    printf("Product of polynomials: ");
    for (int i = degreeC; i >= 0; i--) {
        printf("%d(x^%d) ", C[i], i);
        if (i > 0) printf("+ ");
    }
    printf("\n");
}

// Function to differentiate a polynomial
void differentiatePolynomial(int degreeA, int A[]) {
    printf("Derivative of polynomial: ");
    for (int i = degreeA; i > 0; i--) {
        printf("%d(x^%d) ", A[i] * i, i - 1);
        if (i > 1) printf("+ ");
    }
    printf("\n");
}

int main() {
    int degreeA, degreeB, choice;

    // Input for Polynomial A
    printf("Enter degree of Polynomial A: ");
    scanf("%d", &degreeA);
    int A[degreeA + 1];

    for (int i = degreeA; i >= 0; i--) {
        printf("Coefficient of x^%d: ", i);
        scanf("%d", &A[i]);
    }

    // Menu for choosing operation
    printf("\nChoose an operation:\n");
    printf("1. Add Polynomials\n");
    printf("2. Subtract Polynomials\n");
    printf("3. Multiply Polynomials\n");
    printf("4. Differentiate Polynomial A\n");
    printf("Enter your choice (1-4): ");
    scanf("%d", &choice);

    if (choice == 1 || choice == 2 || choice == 3) {
        // Input for Polynomial B (needed for addition, subtraction, multiplication)
        printf("Enter degree of Polynomial B: ");
        scanf("%d", &degreeB);
        int B[degreeB + 1];

        for (int i = degreeB; i >= 0; i--) {
            printf("Coefficient of x^%d: ", i);
            scanf("%d", &B[i]);
        }

        if (choice == 1) addPolynomials(degreeA, A, degreeB, B);
        if (choice == 2) subtractPolynomials(degreeA, A, degreeB, B);
        if (choice == 3) multiplyPolynomials(degreeA, A, degreeB, B);
    } else if (choice == 4) {
        differentiatePolynomial(degreeA, A);
    } else {
        printf("Invalid choice!\n");
    }

    return 0;
}






/*Step 1: Input Polynomial A
Ask the user to input the degree of Polynomial A.

Read and store coefficients of Polynomial A in an array.

Step 2: Choose an Operation
Display a menu with four options:

1. Addition

2. Subtraction

3. Multiplication

4. Differentiation

Read the user�s choice.

Step 3: Perform the Selected Operation
For Addition & Subtraction:

Ask the user for the degree of Polynomial B.

Read and store coefficients of Polynomial B in another array.

Find the maximum degree of both polynomials.

Add or subtract corresponding coefficients and store the result in a third array.

Print the resultant polynomial.

For Multiplication:

Ask the user for the degree of Polynomial B.

Read and store coefficients of Polynomial B in another array.

Initialize a result array with size equal to (degreeA + degreeB).

Perform multiplication using nested loops:

Multiply each term of A with each term of B and add to the corresponding power in the result array.

Print the resultant polynomial.

For Differentiation:

Multiply each coefficient of Polynomial A by its corresponding exponent.

Store the result in a new array and reduce the power by 1.

Print the derivative of the polynomial.

Step 4: Display the Result
Print the final polynomial in proper notation.

Time Complexity Analysis
Operation	Complexity	Explanation
Addition	O(n)	Iterates once over the largest polynomial.
Subtraction	O(n)	Same as addition.
Multiplication	O(n�)	Nested loop iterates over both polynomials.
Differentiation	O(n)	Single pass over polynomial terms.*/

