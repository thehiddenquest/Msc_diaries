#include <stdio.h>
#include <stdlib.h>

// Node structure for AVL tree
typedef struct AVLNode {
    int key;
    struct AVLNode *left, *right;
    int height;
} AVLNode;

// Function to create a new AVL tree node
AVLNode* createNode(int key) {
    AVLNode* node = (AVLNode*)malloc(sizeof(AVLNode));
    node->key = key;
    node->left = node->right = NULL;
    node->height = 1; // Initial height
    return node;
}

// Get height of the tree
int height(AVLNode* node) {
    return node ? node->height : 0;
}

// Get balance factor of a node
int getBalance(AVLNode* node) {
    return node ? height(node->left) - height(node->right) : 0;
}

// Right rotate subtree rooted with y
AVLNode* rightRotate(AVLNode* y) {
    printf("Right Rotating at node: %d\n", y->key);
    AVLNode* x = y->left;
    AVLNode* T2 = x->right;

    // Rotation
    x->right = y;
    y->left = T2;

    // Update heights
    y->height = 1 + (height(y->left) > height(y->right) ? height(y->left) : height(y->right));
    x->height = 1 + (height(x->left) > height(x->right) ? height(x->left) : height(x->right));

    return x;
}

// Left rotate subtree rooted with x
AVLNode* leftRotate(AVLNode* x) {
    printf("Left Rotating at node: %d\n", x->key);
    AVLNode* y = x->right;
    AVLNode* T2 = y->left;

    // Rotation
    y->left = x;
    x->right = T2;

    // Update heights
    x->height = 1 + (height(x->left) > height(x->right) ? height(x->left) : height(x->right));
    y->height = 1 + (height(y->left) > height(y->right) ? height(y->left) : height(y->right));

    return y;
}

// Insert a key into the AVL tree
AVLNode* insert(AVLNode* node, int key) {
    // Perform standard BST insertion
    if (!node)
        return createNode(key);
    
    if (key < node->key)
        node->left = insert(node->left, key);
    else if (key > node->key)
        node->right = insert(node->right, key);
    else
        return node; // No duplicate keys

    // Update height
    node->height = 1 + (height(node->left) > height(node->right) ? height(node->left) : height(node->right));

    // Get balance factor
    int balance = getBalance(node);

    // Balance the tree
    if (balance > 1 && key < node->left->key) // Left Left Case
        return rightRotate(node);
    
    if (balance < -1 && key > node->right->key) // Right Right Case
        return leftRotate(node);
    
    if (balance > 1 && key > node->left->key) { // Left Right Case
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    if (balance < -1 && key < node->right->key) { // Right Left Case
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}

// Find the node with minimum key
AVLNode* minValueNode(AVLNode* node) {
    AVLNode* current = node;
    while (current->left)
        current = current->left;
    return current;
}

// Delete a key from the AVL tree
AVLNode* deleteNode(AVLNode* root, int key) {
    if (!root)
        return root;

    if (key < root->key)
        root->left = deleteNode(root->left, key);
    else if (key > root->key)
        root->right = deleteNode(root->right, key);
    else {
        if (!root->left || !root->right) {
            AVLNode* temp = root->left ? root->left : root->right;
            if (!temp) { // No child case
                temp = root;
                root = NULL;
            } else
                *root = *temp;
            free(temp);
        } else {
            AVLNode* temp = minValueNode(root->right);
            root->key = temp->key;
            root->right = deleteNode(root->right, temp->key);
        }
    }

    if (!root)
        return root;

    // Update height
    root->height = 1 + (height(root->left) > height(root->right) ? height(root->left) : height(root->right));

    // Get balance factor
    int balance = getBalance(root);

    // Balance the tree
    if (balance > 1 && getBalance(root->left) >= 0) // Left Left Case
        return rightRotate(root);
    
    if (balance > 1 && getBalance(root->left) < 0) { // Left Right Case
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }

    if (balance < -1 && getBalance(root->right) <= 0) // Right Right Case
        return leftRotate(root);
    
    if (balance < -1 && getBalance(root->right) > 0) { // Right Left Case
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }

    return root;
}

// In-order traversal (sorted order)
void inOrder(AVLNode* root) {
    if (root) {
        inOrder(root->left);
        printf("%d ", root->key);
        inOrder(root->right);
    }
}

// Function for post-order traversal (Left -> Right -> Root)
void postOrder(AVLNode* node) {
    if (node != NULL) {
        postOrder(node->left);
        postOrder(node->right);
        printf("%d ", node->key);
    }
}

// Function for pre-order traversal (Root -> Left -> Right)
void preOrder(AVLNode* node) {
    if (node != NULL) {
        printf("%d ", node->key);
        preOrder(node->left);
        preOrder(node->right);
    }
}

// Main function
int main() {
    AVLNode* root = NULL;
    int n, value, choice;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    printf("Enter %d elements to insert: ", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &value);
        root = insert(root, value);
    }

    printf("\nAVL Tree after insertion (In-order traversal): ");
    inOrder(root);
    printf("\n");

    printf("\nPost-order traversal: ");
    postOrder(root);
    printf("\n");

    printf("\nPre-order traversal: ");
    preOrder(root);
    printf("\n");

    while (1) {
        printf("\nEnter 1 to delete an element, 0 to exit: ");
        scanf("%d", &choice);
        if (choice == 0)
            break;
        
        printf("Enter element to delete: ");
        scanf("%d", &value);
        root = deleteNode(root, value);

        printf("\nAVL Tree after deletion (In-order traversal): ");
        inOrder(root);
        printf("\n");
    }

    return 0;
}
