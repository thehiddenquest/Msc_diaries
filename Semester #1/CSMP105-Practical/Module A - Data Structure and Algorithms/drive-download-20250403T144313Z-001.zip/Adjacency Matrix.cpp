#include <stdio.h>

#define MAX 100  // Maximum number of vertices

// Function to display the adjacency matrix
void displayMatrix(int matrix[MAX][MAX], int vertices) {
    printf("\nAdjacency Matrix:\n");
    for (int i = 0; i < vertices; i++) {
        for (int j = 0; j < vertices; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int matrix[MAX][MAX] = {0}; // Initialize all values to 0
    int vertices, edges, choice, src, dest, weight;
    
    // Get number of vertices
    printf("Enter the number of vertices: ");
    scanf("%d", &vertices);
    
    // Get type of graph from user
    printf("Choose the type of graph:\n");
    printf("1. Undirected Unweighted\n");
    printf("2. Undirected Weighted\n");
    printf("3. Directed Unweighted\n");
    printf("4. Directed Weighted\n");
    printf("Enter your choice (1-4): ");
    scanf("%d", &choice);
    
    // Get number of edges
    printf("Enter the number of edges: ");
    scanf("%d", &edges);
    
    for (int i = 0; i < edges; i++) {
        printf("Enter edge (source destination): ");
        scanf("%d %d", &src, &dest);
        
        if (choice == 2 || choice == 4) { // Weighted graphs
            printf("Enter weight: ");
            scanf("%d", &weight);
        } else {
            weight = 1; // Unweighted graphs default to 1
        }

        // Store in adjacency matrix
        matrix[src][dest] = weight;
        if (choice == 1 || choice == 2) { // Undirected graph
            matrix[dest][src] = weight;
        }
    }
    
    // Display the adjacency matrix
    displayMatrix(matrix, vertices);
    
    return 0;
}

