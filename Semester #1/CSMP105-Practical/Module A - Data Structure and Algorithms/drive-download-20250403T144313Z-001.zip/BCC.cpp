#include <stdio.h>
#include <stdlib.h>

#define MAX 1000  // Maximum number of nodes

typedef struct Node {
    int vertex;
    struct Node* next;
} Node;

Node* adj[MAX];  // Adjacency list
int dfn[MAX], low[MAX], parent[MAX], timeStamp = 0;
int stack[MAX], top = -1;
int n, m;

// **Function to add an edge**
void addEdge(int u, int v) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->vertex = v;
    newNode->next = adj[u];
    adj[u] = newNode;
}

// **Recursive DFS Function for BCC**
void dfs(int u) {
    dfn[u] = low[u] = ++timeStamp;
    stack[++top] = u; // Push to stack

    Node* temp = adj[u];
    while (temp) {
        int v = temp->vertex;
        if (dfn[v] == 0) { // Unvisited node
            parent[v] = u;
            dfs(v);

            low[u] = (low[u] < low[v]) ? low[u] : low[v];

            // **Condition for BCC**
            if (low[v] >= dfn[u]) {
                printf("\nBiconnected Component: ");
                int w;
                do {
                    w = stack[top--];
                    printf("%d ", w);
                } while (w != v);
                printf("%d\n", u);
            }
        } else if (v != parent[u]) { // Back edge
            low[u] = (low[u] < dfn[v]) ? low[u] : dfn[v];
        }
        temp = temp->next;
    }
}

// **Display Adjacency List**
void printGraph() {
    printf("\nAdjacency List:\n");
    for (int i = 1; i <= n; i++) {
        printf("[%d] -> ", i);
        Node* temp = adj[i];
        while (temp) {
            printf("%d -> ", temp->vertex);
            temp = temp->next;
        }
        printf("NULL\n");
    }
}

// **Main Function**
int main() {
    printf("Enter number of vertices: ");
    scanf("%d", &n);
    printf("Enter number of edges: ");
    scanf("%d", &m);

    printf("Enter edges (format: u v):\n");
    for (int i = 0; i < m; i++) {
        int u, v;
        scanf("%d %d", &u, &v);
        addEdge(u, v);
        addEdge(v, u); // **For undirected graph**
    }

    printGraph();

    // **Initialize and run DFS for each component**
    for (int i = 1; i <= n; i++) {
        if (dfn[i] == 0) {
            dfs(i);
        }
    }

    return 0;
}

