#include <stdio.h>

#define MAX_V 50 // Maximum number of vertices
#define MAX_E 50  // Maximum number of edges

// Function to display the Incidence Matrix
void displayMatrix(int matrix[MAX_V][MAX_E], int vertices, int edges) {
    printf("\nIncidence Matrix:\n");
    for (int i = 0; i < vertices; i++) {
        for (int j = 0; j < edges; j++) {
            printf("%2d ", matrix[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int matrix[MAX_V][MAX_E] = {0};  // Initialize all elements to 0
    int vertices, edges, choice, src, dest, weight;

    // Get number of vertices
    printf("Enter the number of vertices: ");
    scanf("%d", &vertices);

    // Get type of graph
    printf("Choose the type of graph:\n");
    printf("1. Undirected Unweighted\n");
    printf("2. Undirected Weighted\n");
    printf("3. Directed Unweighted\n");
    printf("4. Directed Weighted\n");
    printf("Enter your choice (1-4): ");
    scanf("%d", &choice);

    // Get number of edges
    printf("Enter the number of edges: ");
    scanf("%d", &edges);

    for (int i = 0; i < edges; i++) {
        printf("Enter edge %d (source destination): ", i + 1);
        scanf("%d %d", &src, &dest);

        if (choice == 2 || choice == 4) {  // Weighted graphs
            printf("Enter weight: ");
            scanf("%d", &weight);
        } else {
            weight = 1;  // Default weight for unweighted graphs
        }

        // Update incidence matrix
        if (choice == 1 || choice == 2) {  // Undirected graphs
            matrix[src][i] = weight;
            matrix[dest][i] = weight;
        } else {  // Directed graphs
            matrix[src][i] = -weight;  // Outgoing edge
            matrix[dest][i] = weight;  // Incoming edge
        }
    }

    // Display the incidence matrix
    displayMatrix(matrix, vertices, edges);

    return 0;
}

