/**
 * 
 */
/**
 * 
 */
module assignment1 {
	requires java.desktop;
}