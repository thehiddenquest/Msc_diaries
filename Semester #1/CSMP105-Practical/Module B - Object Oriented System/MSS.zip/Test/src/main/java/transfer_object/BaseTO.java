package transfer_object;

public interface BaseTO {

}
