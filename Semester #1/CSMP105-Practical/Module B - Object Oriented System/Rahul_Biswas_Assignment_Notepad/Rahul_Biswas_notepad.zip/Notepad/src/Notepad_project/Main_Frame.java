package Notepad_project;

public class Main_Frame {

	public static void main(String[] args) {
		MyFrame f = new MyFrame();
		f.setVisible(true);
	}

}
