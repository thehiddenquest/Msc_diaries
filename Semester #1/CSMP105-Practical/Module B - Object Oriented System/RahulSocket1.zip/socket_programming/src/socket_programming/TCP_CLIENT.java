package socket_programming;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;

public class TCP_CLIENT {
	
	static String readCProg () throws IOException {
		String result = "";
		BufferedReader cprog;
		try {
			cprog = new BufferedReader(new FileReader("sum.c"));
			while(cprog.ready()) {
				result += cprog.readLine() + "  ";
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
	public static void main(String args[]) throws Exception{
		String sendProg = readCProg();
		String receiveProg;
		Socket clientSocket = new Socket("localhost",3000);
		OutputStream outToServer = clientSocket.getOutputStream();
		BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
		outToServer.write((sendProg+"\n").getBytes());
		receiveProg = inFromServer.readLine();
		String[] output = receiveProg.split("  ");
		for(int i=0;i<output.length;i++) {
			System.out.println(output[i]);
		}
		clientSocket.close();
		
	}
}
