package socket_programming;

import java.io.File;

public class Temp {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		ProcessBuilder pb = 
				   new ProcessBuilder("dir");
				pb.directory(new File("C:/"));
				pb.redirectErrorStream(true);

				Process p = pb.start();
	}

}
