package socket_programming;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;


public class TCP_SERVER {

    static void printProg(String prog) {
        String[] result = prog.split("  ");
        for (int i = 0; i < result.length; i++) {
            System.out.println(result[i]);
        }
    }

    public static void main(String args[]) throws Exception {
        String sendProg;
        String receiveProg;
        try (ServerSocket welcomesocket = new ServerSocket(3000)) {
            while (true) {
                System.out.println("Server");
                Socket connectionSocket = welcomesocket.accept();
                BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
                OutputStream outToClient = connectionSocket.getOutputStream();

                // Read the received C program
                sendProg = inFromClient.readLine();
                System.out.println("Getting C Program Output:\n");

                // Create a temporary C file
                String fileName = "temp.c";
                try (PrintWriter writer = new PrintWriter(fileName)) {
                    writer.println(sendProg);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                // Compile the temporary C file using Runtime
                try {
                    ProcessBuilder compilerProcessBuilder = new ProcessBuilder("gcc", fileName);
                    compilerProcessBuilder.redirectErrorStream(true); // Redirect error stream to input stream

                    Process compilerProcess = compilerProcessBuilder.start();
                    int compilerExitCode = compilerProcess.waitFor();

                    // Read the output and error streams of the compilation process
                    InputStream inputStream = compilerProcess.getInputStream();
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                    BufferedReader compilerOutputReader = new BufferedReader(inputStreamReader);

                    StringBuilder compilerOutput = new StringBuilder();
                    String line;
                    while ((line = compilerOutputReader.readLine()) != null) {
                        compilerOutput.append(line).append("\n");
                    }

                    // Check if compilation was successful
                    if (compilerExitCode == 0) {
                        receiveProg = "Compilation successful\n" + compilerOutput.toString();
                    } else {
                        receiveProg = "Compilation failed\n" + compilerOutput.toString();
                    }

                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();
                    receiveProg = "Compilation error: " + e.getMessage();
                }

                // Send the result back to the client
                outToClient.write((receiveProg + "\n").getBytes());
                connectionSocket.close();
            }
        }
    }
}