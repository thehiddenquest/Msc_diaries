#include<stdio.h>
#include<stdlib.h>

int main(){
 int a=5;
 int b=6;
 printf("Sum: %d",a+b);
 return 0;
}
