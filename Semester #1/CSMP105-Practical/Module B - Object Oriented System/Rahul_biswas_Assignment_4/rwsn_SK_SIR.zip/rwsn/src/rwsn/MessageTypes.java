package rwsn;

public enum MessageTypes {
	DATA, RECHARGE, REQUEST, COMPLETION
}
