package rwsn;

import java.awt.Graphics2D;

public interface DisplayObject {
	public void draw(Graphics2D g);
}
