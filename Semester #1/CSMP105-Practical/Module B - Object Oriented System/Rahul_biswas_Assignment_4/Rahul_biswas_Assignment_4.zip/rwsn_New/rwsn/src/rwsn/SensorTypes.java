package rwsn;

public enum SensorTypes {
	TEMPERATURE, HUMIDITY
}
