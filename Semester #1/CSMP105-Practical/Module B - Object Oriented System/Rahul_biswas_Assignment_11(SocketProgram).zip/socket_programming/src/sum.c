#include<stdio.h>
#include<stdlib.h>

int main(){
 int a=5;
 int b=6;
 int c = b-a;
 printf("Sum: %d",c);
 return 0;
}
