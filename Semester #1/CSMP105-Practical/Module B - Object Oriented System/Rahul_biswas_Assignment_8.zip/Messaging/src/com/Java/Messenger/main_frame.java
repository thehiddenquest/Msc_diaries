package com.Java.Messenger;

public class main_frame {

	public static void main(String[] args) {
		new gui();
	}

}
