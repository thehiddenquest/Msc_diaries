package com.Java.Messenger;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Actions implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
	}

}
