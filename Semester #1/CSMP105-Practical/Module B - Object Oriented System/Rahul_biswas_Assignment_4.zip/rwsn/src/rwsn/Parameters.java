package rwsn;

/**
 * 
 * @author Sunirmal Khatua
 *
 */
public class Parameters {
	static double InitialEnergy=5.0;
	static double ThresholdEnergy = 2.0;
}
