package repository;

public class MySQLRepository implements StorageRepository {

	@Override
	public void store(String filename) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getData(String filename) {
		// TODO Auto-generated method stub
		return null;
	}

}
