package repository;

public interface StorageRepository {
	public void store(String filename);
	public Object getData(String filename);
}
