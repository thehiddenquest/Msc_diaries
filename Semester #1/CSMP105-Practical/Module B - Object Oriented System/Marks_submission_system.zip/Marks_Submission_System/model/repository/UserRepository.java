package repository;

public class UserRepository implements BaseRepository {

	private StorageRepository repository;
    public UserRepository(StorageRepository repository){
        this.repository=repository;
    }
	public StorageRepository getRepository(){
		return repository;
	}

     public void save() {

        repository.store("user.db");
        
    }
    public Object load() {
    	Object obj = repository.getData("user.db");
    	return obj;
    }

}
