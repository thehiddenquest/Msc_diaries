package repository;

public class MarksRepository implements BaseRepository {

	@Override
	public void save() {
		
		
	}

	@Override
	public StorageRepository getRepository() {
		// TODO Auto-generated method stub
		return null;
	}

}
