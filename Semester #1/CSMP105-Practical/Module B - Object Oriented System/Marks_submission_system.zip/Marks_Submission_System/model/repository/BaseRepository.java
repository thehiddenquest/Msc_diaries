package repository;

public interface BaseRepository {
	public void save();
    public StorageRepository getRepository();
}
