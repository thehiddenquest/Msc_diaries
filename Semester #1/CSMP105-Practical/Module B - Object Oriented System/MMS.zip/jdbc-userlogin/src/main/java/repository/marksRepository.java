package repository;

import java.util.ArrayList;

import transfer_object.MarksTO;

public class marksRepository extends baseRepository<Object> {

	public marksRepository(storageRepository<Object> storage) {
		super(storage);
	}

	@Override
	public boolean save(Object marksList) {
	    boolean info = storage.store(marksList);
	    return info;
	}

	@Override
	public MarksTO load(Object obj) {
		MarksTO marks = (MarksTO)storage.retrive(obj);
		return marks;
	}

	@Override
	public boolean delete(Object user) {
		boolean info = storage.remove(user);
		return info;
	}

}
