package com.Java.Messenger;

public class main_frame {

	public static void main(String[] args) {
		//new loginWindow();
		new gui("codehub5565@gmail.com","yfcp wgiu bjqr rmcs","1","1");
	}

}
