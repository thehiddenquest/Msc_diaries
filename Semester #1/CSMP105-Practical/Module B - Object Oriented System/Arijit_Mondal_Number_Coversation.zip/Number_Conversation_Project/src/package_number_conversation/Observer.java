package package_number_conversation;

public abstract class Observer {
	public Subject subject=null;
	public abstract void update();
	
}
