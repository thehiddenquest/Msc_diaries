package rwsn;

public class Parameters {
	static double InitialEnergy=5.0;
	static double ThresholdEnergy = 1.0;
}
