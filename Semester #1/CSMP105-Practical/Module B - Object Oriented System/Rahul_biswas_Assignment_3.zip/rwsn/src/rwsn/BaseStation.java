//package rwsn;
//
//import java.awt.Graphics2D;
//import java.awt.Image;
//import java.util.Hashtable;
//
//import javax.swing.ImageIcon;
//import javax.swing.JOptionPane;
//
//public class BaseStation implements DisplayObject {
//
//	Image img;
//	int x,y;
//	private CircularQueue cq = new CircularQueue();
//	public BaseStation(int x, int y) {
//		this.x=x;
//		this.y=y;
//		img = new ImageIcon(getClass().getResource("/images/bs.png")).getImage();
//	}
//	
//	@Override
//	public void draw(Graphics2D g) {
//		g.drawImage(img,x,y,50,70,null);		
//	}
//	public boolean recive_message(String Message,Sensor s) {
//		
//		cq.enQueue(s);
//		if(Message == null) {
//			System.out.println(s.id+" needs charging");
//			return true;
//		}
//		else {
//			return false;
//		}
//			
//	}
//	public void displayCircularQueueWithJOptionPane() {
//	    StringBuilder queueContent = new StringBuilder("Circular Queue Content:\n");
//
//	    for (DisplayObject obj : cq) {
//	        queueContent.append(obj.toString()).append("\n");
//	    }
//
//	    JOptionPane.showMessageDialog(null, queueContent.toString(), "Circular Queue", JOptionPane.INFORMATION_MESSAGE);
//	}
//}
package rwsn;

import java.awt.Graphics2D;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

public class BaseStation implements DisplayObject {

    Image img;
    int x, y;
    private CircularQueue<Sensor> sensedDataHistory = new CircularQueue<>();
    private List<Sensor> chargingRequests = new ArrayList<>();

    public BaseStation(int x, int y) {
        this.x = x;
        this.y = y;
        img = new ImageIcon(getClass().getResource("/images/bs.png")).getImage();
    }

//    @Override
//    public void draw(Graphics2D g) {
//        g.drawImage(img, x, y, 50, 70, null);
//        displayCircularQueueWithJOptionPane();
//        displayChargingRequests();
//    }

    public boolean recive_message(String Message, Sensor s) {
        sensedDataHistory.enQueue(s);

        if (Message == null) {
            System.out.println(s.id + " needs charging");
            addChargingRequest(s);
            return true;
        } else {
            return false;
        }
    }

//    public void displayCircularQueueWithJOptionPane() {
//        StringBuilder queueContent = new StringBuilder("Sensed Data History:\n");
//
//        for (Sensor sensor : sensedDataHistory) {
//            queueContent.append(sensor.toString()).append("\n");
//        }
//
//        JOptionPane.showMessageDialog(null, queueContent.toString(), "Sensed Data History", JOptionPane.INFORMATION_MESSAGE);
//    }

    private void addChargingRequest(Sensor sensor) {
        chargingRequests.add(sensor);
        chargingRequests.sort((s1, s2) -> Double.compare(s1.remainingEnergy, s2.remainingEnergy));
    }

//    private void displayChargingRequests() {
//        StringBuilder requestContent = new StringBuilder("Charging Requests:\n");
//
//        for (Sensor sensor : chargingRequests) {
//            requestContent.append(sensor.toString()).append("\n");
//        }
//
//        JOptionPane.showMessageDialog(null, requestContent.toString(), "Charging Requests", JOptionPane.INFORMATION_MESSAGE);
//    }
    @Override
    public void draw(Graphics2D g) {
        g.drawImage(img, x, y, 50, 70, null);
        drawCircularQueue(g, sensedDataHistory, "Sensed Data History:");
        drawChargingRequests(g, chargingRequests, "Charging Requests:");
    }

    private void drawCircularQueue(Graphics2D g, CircularQueue<Sensor> queue, String label) {
        StringBuilder content = new StringBuilder(label + "\n");

        for (Sensor sensor : queue) {
            content.append(sensor.toString()).append("\n");
        }

        // Draw the content on the canvas at a specific location
        g.drawString(content.toString(), x, y + 100); // Adjust the coordinates as needed
    }

    private void drawChargingRequests(Graphics2D g, List<Sensor> requests, String label) {
        StringBuilder content = new StringBuilder(label + "\n");

        for (Sensor sensor : requests) {
            content.append(sensor.toString()).append("\n");
        }

        // Draw the content on the canvas at a specific location
        g.drawString(content.toString(), x, y + 200); // Adjust the coordinates as needed
    }
}