package CodeConversionModel;


public abstract class Observer {
	public Subject subject=null;
	public abstract void update();
}
