package respository;

import transfer_object.BaseTO;

public class MarksRepository implements BaseRepository {

	@Override
	public StorageRepository getRepository() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(BaseTO BD) {
		// TODO Auto-generated method stub
		
	}

}
