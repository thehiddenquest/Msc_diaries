

public class Node {
	
	protected Terms term;
	protected Node next;
	
	public Node(Terms t, Node n) {
		term = t;
		next = n;
	}
}
