package myproject;

public abstract class Notification {
	public abstract void notify(String sender, String reciver, String message);
}
