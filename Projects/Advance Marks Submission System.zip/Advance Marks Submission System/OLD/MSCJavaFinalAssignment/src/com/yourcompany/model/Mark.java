// Mark.java
package com.yourcompany.model;

public class Mark {
    private int studentId;
    private String subject;
    private int marks;

    // Constructors, getters, setters
}