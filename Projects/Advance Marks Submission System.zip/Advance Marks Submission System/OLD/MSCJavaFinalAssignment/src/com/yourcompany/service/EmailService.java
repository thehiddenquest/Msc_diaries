// EmailService.java
package com.yourcompany.service;

import com.yourcompany.model.Report;

public class EmailService {
    public void sendReportByEmail(String recipient, Report report) {
        // Send report via email
    }
}
