// Report.java
package com.yourcompany.model;

public class Report {
    private String data;

	public char[] getData() {
		// TODO Auto-generated method stub
		return null;
	}

    // Constructors, getters, setters
}