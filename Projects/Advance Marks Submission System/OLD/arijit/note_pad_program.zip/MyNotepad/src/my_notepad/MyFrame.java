package my_notepad;

import java.awt.BorderLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;

import javax.swing.*;

public class MyFrame extends JFrame implements ActionListener {

	public MyFrame() {
		setTitle("Notepad");
		setSize(600, 300);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		initComponents();
	}

	public void initComponents() {

		JMenuBar mb = new JMenuBar();
		JMenu file = new JMenu("File");
		JMenu edit = new JMenu("Edit");
		JMenu format = new JMenu("Format");
		JMenu view = new JMenu("View");
		JMenu help = new JMenu("Help");

		JMenuItem newit = new JMenuItem("New");
		JMenuItem open = new JMenuItem("Open");
		JMenuItem save = new JMenuItem("Save");
		JMenuItem exit = new JMenuItem("Exit");

		newit.addActionListener(this);
		open.addActionListener(this);
		save.addActionListener(this);
		exit.addActionListener(this);

		JMenuItem undo = new JMenuItem("Undo");
		JMenuItem cut = new JMenuItem("Cut");
		JMenuItem paste = new JMenuItem("Paste");
		JMenuItem delete = new JMenuItem("Delete");

		file.add(newit);
		file.add(open);
		file.add(save);
		file.add(exit);

		edit.add(undo);
		edit.add(cut);
		edit.add(paste);
		edit.add(delete);

		mb.add(file);
		mb.add(edit);
		mb.add(format);
		mb.add(view);
		mb.add(help);

		add(mb, BorderLayout.NORTH);

	}

	public static void main(String[] args) {

		MyFrame f = new MyFrame();
		f.setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if (cmd.equalsIgnoreCase("Exit")) {
			System.exit(0);
		} else if (cmd.equalsIgnoreCase("New")) {
			JTextArea area = new JTextArea();
			JScrollPane sp = new JScrollPane(area);
			add(sp);
			validate();
		} else if (cmd.equalsIgnoreCase("Open")) {
			try {
				JFileChooser fc = new JFileChooser();
				if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
					File f = fc.getSelectedFile();
					FileReader fr = new FileReader(f);
					JTextArea area = new JTextArea();
					area.read(fr,null);
					add(area);
					validate();
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		else if (cmd.equalsIgnoreCase("Save")) {
			try {
				JFileChooser fc = new JFileChooser();
				if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
					File f = fc.getSelectedFile();
					FileWriter fw = new FileWriter(f.getAbsoluteFile(), true);
					JTextArea area = new JTextArea();
					area.getText();
					area.write(fw);
					validate();
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

}
