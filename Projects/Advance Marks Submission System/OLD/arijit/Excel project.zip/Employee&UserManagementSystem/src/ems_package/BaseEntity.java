package ems_package;

public abstract class BaseEntity {
	
}
