package Abstract_factory;

public interface Shape {
	public void draw();

}
