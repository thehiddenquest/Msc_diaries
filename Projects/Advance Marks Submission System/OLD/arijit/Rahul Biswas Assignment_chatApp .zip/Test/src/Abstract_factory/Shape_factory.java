package Abstract_factory;

public class Shape_factory extends Abstract_fact {
	
	public Shape get_shape(String type)
	{
		if(type==null)
		{
			return null;
		}
		else if(type.equalsIgnoreCase("Circle"))
		{
			return new Circle();
		}
		else
		{
			return new Triangle();
		}
	}
	public Colour get_colour(String type)
	{
		return null;
	}

}
