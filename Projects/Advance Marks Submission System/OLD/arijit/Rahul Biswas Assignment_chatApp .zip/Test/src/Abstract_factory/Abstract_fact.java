package Abstract_factory;

abstract class Abstract_fact {
	
	public abstract Shape get_shape(String type);
	public abstract Colour get_colour(String type);

}
