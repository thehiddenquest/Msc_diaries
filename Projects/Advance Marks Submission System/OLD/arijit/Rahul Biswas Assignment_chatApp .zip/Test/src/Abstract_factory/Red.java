package Abstract_factory;

public class Red implements Colour {
	public void fill()
	{
		System.out.println("Red colour");
	}

}
