package Abstract_factory;

public class Colour_factory extends Abstract_fact {
	
	public Colour get_colour(String type)
	{
		if(type==null)
		{
			return null;
			
		}
		else if(type.equalsIgnoreCase("Red"))
		{
			return new Red();
		}
		else
		{
			return new Blue();
		}
	}
	public Shape get_shape(String type)
	{
		return null;
	}

}
