package Abstract_factory;

public class Blue implements Colour {
	public void fill()
	{
		System.out.println("Blue colour");
	}

}
