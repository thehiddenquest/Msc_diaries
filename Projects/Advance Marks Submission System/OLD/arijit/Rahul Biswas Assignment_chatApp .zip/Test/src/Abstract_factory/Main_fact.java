package Abstract_factory;

public class Main_fact {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Abstract_fact abs=Creator_fact.get_fact("Shape");
		Shape s=abs.get_shape("triangle");
		s.draw();

	}

}
