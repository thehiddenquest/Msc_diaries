package Abstract_factory;

public interface Colour {
	public void fill();

}
