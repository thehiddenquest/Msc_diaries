package Abstract_factory;

public class Creator_fact {
	
	public static Abstract_fact get_fact(String type)
	{
		if(type==null)
		{
			return null;
		}
		else if(type.equalsIgnoreCase("Shape"))
		{
			return new Shape_factory();
			
		}
		else
		{
			return new Colour_factory();
		}
	}

}
