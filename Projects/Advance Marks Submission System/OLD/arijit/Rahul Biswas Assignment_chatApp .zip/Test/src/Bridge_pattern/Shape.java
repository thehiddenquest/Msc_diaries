package Bridge_pattern;

public abstract class Shape {
	
	protected Draw_Api draw_api;
	protected Shape(Draw_Api draw_api)
	{
		this.draw_api=draw_api;
	}
	public abstract void draw();

}
