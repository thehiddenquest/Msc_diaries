package Bridge_pattern;

public class Circle extends Shape {
	
	private int x,y;
	
	public Circle(int x,int y,Draw_Api draw_api)
	{
		super(draw_api);
		this.x=x;
		this.y=y;
	}
	public void draw()
	{
		draw_api.draw_circle(x, y);
	}

}
