package Bridge_pattern;

public class Bridge_demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape red_circle=new Circle(100,100,new Red_circle());
		Shape green_circle=new Circle(100,50,new Green_circle());
		
		red_circle.draw();
		green_circle.draw();

	}

}
