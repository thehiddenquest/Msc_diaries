package Bridge_pattern;

public interface Draw_Api {
	
	public void draw_circle(int x,int y);

}
