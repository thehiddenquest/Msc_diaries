package Bridge_pattern;

public class Green_circle implements Draw_Api {
	
	
	
	public void draw_circle(int x,int y)
	{
		System.out.println("x :"+x+"y :"+y);
	}
	

}
