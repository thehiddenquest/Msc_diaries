package Pool;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Random;

public class RandomNumber_Pool {
	 public static void main(String[] args) throws FileNotFoundException {
	        // Create a file containing 100 random numbers
	        createRandomNumberFile(100, "random_numbers.txt");

	        // Create a pool of RandomNumber objects
	        RandomNumberPool pool = new RandomNumberPool("random_numbers.txt", 10);

	        // Print the pool contents
	        System.out.println("Initial pool:");
	        pool.printPool();

	        // Resize the pool to 5 elements
	        pool.resizePool(5);

	        // Print the pool contents again
	        System.out.println("\nPool after resize:");
	        pool.printPool();
	    }

	    private static void createRandomNumberFile(int numNumbers, String filename) throws FileNotFoundException {
	        Random random = new Random();
	        File file = new File(filename);
	        PrintWriter writer = new PrintWriter(file);

	        for (int i = 0; i < numNumbers; i++) {
	            writer.println(random.nextInt(1000));
	        }

	        writer.close();
	    }

}
