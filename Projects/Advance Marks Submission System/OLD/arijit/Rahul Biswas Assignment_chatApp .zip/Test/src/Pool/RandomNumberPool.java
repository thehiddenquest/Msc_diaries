package Pool;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;


class RandomNumberPool {

    private ArrayList<RandomNumber> pool;

    public RandomNumberPool(String filename, int poolSize) throws FileNotFoundException {
        pool = new ArrayList<RandomNumber>();

        for (int i = 0; i < poolSize; i++) {
            pool.add(new RandomNumber(filename, 10));
        }
    }

    public void resizePool(int newSize) throws FileNotFoundException {
        if (newSize < pool.size()) {
            pool.subList(newSize, pool.size()).clear();
        } else {
            for (int i = pool.size(); i < newSize; i++) {
                pool.add(new RandomNumber("random_numbers.txt", 10));
            }
        }
    }

    public void printPool() {
        for (RandomNumber randomNumber : pool) {
            randomNumber.printNumbers();
        }
    }
}

