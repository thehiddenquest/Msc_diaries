package Pool;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;

public class RandomNumber {
	
	private ArrayList<Integer> numbers;

    public RandomNumber(String filename, int numNumbers) throws FileNotFoundException {
        numbers = new ArrayList<Integer>();
        Scanner scanner = new Scanner(new File(filename));

        for (int i = 0; i < numNumbers; i++) {
            if (scanner.hasNextInt()) {
                numbers.add(scanner.nextInt());
            }
        }

        scanner.close();
    }

    public void printNumbers() {
        for (int number : numbers) {
            System.out.print(number + " ");
        }
        System.out.println();
    }

}
