package Factory_pattern;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pizza_store p=new Pizza_store();
		Pizza pizza=p.get_pizza("chicken", "American");
		pizza.prepare();
		pizza.bake();
		pizza.cut();
		pizza.box();


	}

}
