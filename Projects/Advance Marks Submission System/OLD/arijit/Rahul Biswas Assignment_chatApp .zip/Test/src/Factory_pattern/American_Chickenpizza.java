package Factory_pattern;

public class American_Chickenpizza implements Chicken_pizza,Pizza {
	
	public void prepare()
	{
		System.out.println("Prepare the pizza with all ingredients based on American style");
		
	}
	public void bake()
	{
		System.out.println("Bake the pizza");
		
	}
	
	public void cut()
	{
		System.out.println("Cut the pizza");
		
	}
	public void box()
	{
		System.out.println("Pack the pizza");
		
	}

}
