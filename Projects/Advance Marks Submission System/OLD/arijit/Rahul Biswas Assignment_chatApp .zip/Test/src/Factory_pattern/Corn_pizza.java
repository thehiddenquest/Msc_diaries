package Factory_pattern;

public interface Corn_pizza extends Pizza {
	
	public void prepare();
	public void bake();
	public void cut();
	public void box();
	
	
	


}
