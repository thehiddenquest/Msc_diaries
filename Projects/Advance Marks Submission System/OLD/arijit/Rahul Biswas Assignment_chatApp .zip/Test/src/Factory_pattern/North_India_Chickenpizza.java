package Factory_pattern;

public class North_India_Chickenpizza implements Chicken_pizza,Pizza {
	
	public void prepare()
	{
		System.out.println("Prepare the pizza with all ingredients based on north india");
		
	}
	public void bake()
	{
		System.out.println("Bake the pizza");
		
	}
	public void chicken()
	{
		System.out.println("Add toppings of chicken");
	}
	public void paneer()
	{
		System.out.println("Add toppings of paneer");
	}
	public void corn()
	{
		System.out.println("Add toppings of corn");
	}
	public void cut()
	{
		System.out.println("Cut the pizza");
		
	}
	public void box()
	{
		System.out.println("Pack the pizza");
		
	}

}
