package Factory_pattern;

public class Pizza_store {
	
	public Pizza get_pizza(String type,String style)
	{
		if(type==null && style==null)
		{
			return null;
		}
		if(type.equalsIgnoreCase("Chicken")&& style.equalsIgnoreCase("south india"))
		{
			return new South_India_Chickenpizza();
		}
		else if(type.equalsIgnoreCase("Chicken")&& style.equalsIgnoreCase("north india")) {
			
			return new North_India_Chickenpizza();
		}
		else
		{
			return new American_Chickenpizza();
		}
	}

}
