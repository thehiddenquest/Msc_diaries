package Factory_pattern;

public interface Chicken_pizza extends Pizza {
	
	public void prepare();
	public void bake();
	public void cut();
	public void box();
	

	
	

}
