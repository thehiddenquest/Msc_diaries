package Composite;

import java.util.ArrayList;
import java.util.List;

public class Employee {
	
	private String name;
	private String dept;
	private int sal;
	private static List<Employee> emp;
	public Employee(String name,String dept,int sal)
	{
		this.name=name;
		this.dept=dept;
		this.sal=sal;
		emp=new ArrayList<Employee>();
	}
	public String get_name()
	{
		return name;
	}
	public String get_dept()
	{
		return dept;
	}
	public int get_sal()
	{
		return sal;
	}
	public void add(Employee e)
	{
		emp.add(e);
	}
	public void remove(Employee e)
	{
		emp.remove(e);
	}
	public List<Employee> get_value()
	{
		return emp;
	}
	public String toString()
	{
		return("name :"+name+" Department :"+dept+" Salary :"+sal);
	}

}
