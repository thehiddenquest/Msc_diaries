package Composite;



public class Main {
	public static void main(String[] args)
	{
		 Employee CEO = new Employee("John","CEO", 30000);

	      Employee headSales = new Employee("Robert","Head Sales", 20000);
	      Employee headMarketing = new Employee("Michel","Head Marketing", 20000);
	      
	      CEO.add(headMarketing);
	      CEO.add(headSales);
	      
	      Employee leader_market1=new Employee("Laura","Marketing", 10000);
	      Employee leader_market2=new Employee("Bob","Marketing", 10000);
	      Employee worker_market=new Employee("Richard","Marketing", 10000);
	      
	      headMarketing.add(leader_market1);
	      headMarketing.add(leader_market2);
	      headMarketing.add(worker_market);
	      
	      
	      Employee salesExecutive1 = new Employee("Rob","Sales", 10000);
	      Employee salesExecutive2 = new Employee("Sam","Sales", 10000);
	      Employee worker_sales=new Employee("Rik","Sales", 10000);
	      
	      headSales.add(salesExecutive1);
	      headSales.add(salesExecutive2);
	      headSales.add(worker_sales);
	      
	      System.out.println("Display");
	      System.out.println(CEO);
	      for(Employee employee:CEO.get_value())
	      {
	    	  System.out.println(employee);
	    	  for(Employee head:employee.get_value())
	    	  {
	    		  System.out.println(head);
	    	  }
	      }
	      
	      
	      
	      
	      

	}

}
