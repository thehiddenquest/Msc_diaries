package Random;

public class Result {
	
	private int roll_no,marks;
	public Result(int roll_no,int marks)
	{
		this.roll_no=roll_no;
		this.marks=marks;
	}
	public int get_roll()
	{
		return roll_no;
	}
	public int get_marks()
	{
		return marks;
	}

}
