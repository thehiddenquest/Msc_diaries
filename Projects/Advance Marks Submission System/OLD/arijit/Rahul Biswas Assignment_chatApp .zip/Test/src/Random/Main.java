package Random;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;
		for(i=1;i<=5;i++)
		{
			StudentDAO stu=StudentDAO.get_instance();
			int roll=(int)(Math.random()*100);
			int marks=stu.get_marks(roll);
			System.out.println("Roll :"+roll+" marks: "+marks);
		}

	}

}
