package Random;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentDAO {
	
	private static  StudentDAO obj=null;
	private static ArrayList<Result> results=new ArrayList<Result>();
	
	static {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Result.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(" ");
                results.add(new Result(Integer.parseInt(data[0]), Integer.parseInt(data[1])));
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	private StudentDAO()
	{
		
	}
	public static synchronized StudentDAO get_instance()
	{
		if(obj==null)
		{
			obj=new StudentDAO();
		}
		return obj;
	}
	public int get_marks(int roll)
	{
		for(Result result:results)
		{
			if(result.get_roll()==roll)
			{
				return result.get_marks();
			}
		}
		return -1;
	}
	

}
