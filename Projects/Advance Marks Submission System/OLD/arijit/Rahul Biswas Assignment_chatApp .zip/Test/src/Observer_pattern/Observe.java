package Observer_pattern;

abstract class Observe {
	protected Subject subject;
	abstract void update();

}
