package Observer_pattern;

import java.util.ArrayList;
import java.util.List;

public class Subject {
	
	private List<Observe> observers=new ArrayList<Observe>();
	private int state;
	public int getter()
	{
		return state;
	}
	public void setter(int state)
	{
		this.state=state;
		notify_all_observer();
	}
	public void attach(Observe observer)
	{
		observers.add(observer);
	}
	public void notify_all_observer()
	{
		for(Observe observer:observers)
		{
			observer.update();
		}
	}

}
