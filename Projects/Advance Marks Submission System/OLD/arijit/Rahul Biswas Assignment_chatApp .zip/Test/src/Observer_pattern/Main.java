package Observer_pattern;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Subject subject=new Subject();
		new Binary(subject);
		new Octal(subject);
		System.out.println("Get the values");
		subject.setter(15);

	}

}
