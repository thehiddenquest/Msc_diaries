package Observer_pattern;

public class Binary extends Observe {
	
	public Binary(Subject subject)
	{
		this.subject=subject;
		this.subject.attach(this);
	}
	public void update()
	{
		System.out.println("Binary value is :"+Integer.toBinaryString(subject.getter()));
	}

}
