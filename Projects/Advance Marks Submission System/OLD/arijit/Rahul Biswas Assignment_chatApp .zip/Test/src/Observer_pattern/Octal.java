package Observer_pattern;

public class Octal extends Observe {
	public Octal(Subject subject)
	{
		this.subject=subject;
		this.subject.attach(this);
		
	}
	public void update()
	{
		System.out.println("Octal value is :"+Integer.toOctalString(subject.getter()));
	}

}
