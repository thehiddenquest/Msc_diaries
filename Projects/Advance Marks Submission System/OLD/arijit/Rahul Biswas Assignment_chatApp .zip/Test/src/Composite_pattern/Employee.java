package Composite_pattern;

import java.util.ArrayList;
import java.util.List;

public class Employee {
	
	private String name;
	private String dept;
	private int salary;
	private List<Employee> emp;
	
	public Employee(String name,String dept,int salary)
	{
		this.name=name;
		this.dept=dept;
		this.salary=salary;
		emp=new ArrayList<Employee>();
	}
	public int getter_sal()
	{
		return salary;
	}
	public String getter_name()
	{
		return name;
	}
	public String getter_dept()
	{
		return dept;
		
	}
	public void add(Employee e)
	{
		emp.add(e);
	}
	public void remove(Employee e)
	{
		emp.remove(e);
	}
	public List<Employee> get_subordinates()
	{
		return emp;
	}
	 public void promote(String newDept, int newSalary) {
	      this.dept = newDept;
	      this.salary = newSalary;
	   }
	public String toString()
	{
		return("Employee[name: "+name+" department: "+dept+" salary: "+salary+"]");
	}

}
