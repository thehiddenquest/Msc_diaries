package Composite_pattern;

import java.util.Scanner;

public class Composite_main {
	public static Employee findEmployeeByName(Employee employee, String name) {
	      if (employee.getter_name().equals(name)) {
	         return employee;
	      } else {
	         for (Employee subordinate : employee.get_subordinates()) {
	            Employee foundEmployee = findEmployeeByName(subordinate, name);
	            if (foundEmployee != null) {
	               return foundEmployee;
	            }
	         }
	      }
	      return null;
	   }
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  Employee CEO = new Employee("John","CEO", 30000);

	      Employee headSales = new Employee("Robert","Head Sales", 20000);

	      Employee headMarketing = new Employee("Michel","Head Marketing", 20000);

	      Employee clerk1 = new Employee("Laura","Marketing", 10000);
	      Employee clerk2 = new Employee("Bob","Marketing", 10000);

	      Employee salesExecutive1 = new Employee("Richard","Sales", 10000);
	      Employee salesExecutive2 = new Employee("Rob","Sales", 10000);
	      
	      CEO.add(headSales);
	      CEO.add(headMarketing);

	      headSales.add(salesExecutive1);
	      headSales.add(salesExecutive2);

	      headMarketing.add(clerk1);
	      headMarketing.add(clerk2);
	      
	      
	      int flag;
	      
	     /* for(Employee head:CEO.get_subordinates())
	      {
	    	  for(Employee worker:head.get_subordinates())
	    	  {
	    		  if(worker.getter_name().equalsIgnoreCase("Bob"))
	    		  {
	    			  if(worker.getter_dept().equalsIgnoreCase("Marketing"))
	    			  {
	    				  System.out.println("Bob can only promote to head Marketing");
	    				  
	    				  
	    				  //headMarketing.remove(worker);
	    			      //Employee hm=new Employee("bob","headMarketing",20000);
	    			      //CEO.add(hm);
	    			  }
	    		  }
	    	  }
	      }
	      //System.out.println(test.getter_name());*/
	      
	      
	      
	      
	      
	      for(Employee head:CEO.get_subordinates())
	      {
	    	  System.out.println(head);
	    	  
	    	  
	    	  for(Employee worker:head.get_subordinates())
	    	  {
	    		  System.out.println(worker);
	    		  if(worker.getter_name().equalsIgnoreCase("rob"))
	    		  {
	    			  System.out.println(worker.getter_sal());
	    		  }
	    	  }
	      }
	      Employee employeeToPromote = findEmployeeByName(CEO, "Bob");
	      if (employeeToPromote != null) {
	         employeeToPromote.promote("Head Marketing", 20000);
	         System.out.println("\nPromotion successful!");
	      } else {
	         System.out.println("\nEmployee not found!");
	      }

	      // Print updated employee hierarchy
	      System.out.println("\nUpdated Employee Hierarchy:");
	      System.out.println(CEO); 
	      
	      for (Employee headEmployee : CEO.get_subordinates()) {
	         System.out.println(headEmployee);
	         
	         for (Employee employee : headEmployee.get_subordinates()) {
	            System.out.println(employee);
	         }
	      }
	      int type;
	      Scanner sc=new Scanner(System.in);
	      type=sc.nextInt();
	      System.out.println("Remove of an employee");
	      Employee employeeToRemove = findEmployeeByName(CEO, "Bob");
	      if(employeeToRemove!=null)
	      {
	    	  System.out.println("1.weather department is headMarketing");
	    	  System.out.println("2.weather department is under headMarketing");
	    	  if(type==1) {
	    		  
	    		  headMarketing.remove(employeeToRemove);
	    		  
	    	  }
	    	  else
	    	  {
	    		  //headMarketing.remove(employeeToRemove);
	    	  }
	      }
	      //headMarketing.remove(clerk2);;
	      
	      System.out.println("\nUpdated Employee Hierarchy:");
	      System.out.println(CEO); 
	      
	      for (Employee headEmployee : CEO.get_subordinates()) {
	         System.out.println(headEmployee);
	         
	         for (Employee employee : headEmployee.get_subordinates()) {
	            System.out.println(employee);
	         }
	      
	}
	      System.out.println("1.Add an employee in clerk");
	      System.out.println("2.Add an employee in SalesExcecutive");
	      int temp;
	      int sal;
	      String name,dept;
	      Scanner sc_add=new Scanner(System.in);
	      temp=sc_add.nextInt();
	      if(temp==1)
	      {
	    	  System.out.println("Enter the name");
		      Scanner sc_name=new Scanner(System.in);
		      name=sc_name.next();
		      System.out.println("Enter the department");
		      Scanner sc_dept=new Scanner(System.in);
		      dept=sc_dept.next();
		      System.out.println("Enter the salary");
		      Scanner sc_sal=new Scanner(System.in);
		      sal=sc_sal.nextInt();
		      Employee clerk3=new Employee(name,dept,sal);
		      headMarketing.add(clerk3);
	    	  
	      }
	      else if(temp==2)
	      {
	    	  System.out.println("Enter the name");
		      Scanner sc_name=new Scanner(System.in);
		      name=sc_name.next();
		      System.out.println("Enter the department");
		      Scanner sc_dept=new Scanner(System.in);
		      dept=sc_dept.next();
		      System.out.println("Enter the salary");
		      Scanner sc_sal=new Scanner(System.in);
		      sal=sc_sal.nextInt();
		      Employee salesExecutive3=new Employee(name,dept,sal);
		      headSales.add(salesExecutive3);
	      }
	      System.out.println("\nUpdated Employee Hierarchy:");
	      System.out.println(CEO); 
	      
	      for (Employee headEmployee : CEO.get_subordinates()) {
	         System.out.println(headEmployee);
	         
	         for (Employee employee : headEmployee.get_subordinates()) {
	            System.out.println(employee);
	         }
	      
	}
	      
	

}
}	
