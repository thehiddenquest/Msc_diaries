package Adapter_pattern;

public interface MediaPlayer {
	
	public void play(String type,String filename);

}
