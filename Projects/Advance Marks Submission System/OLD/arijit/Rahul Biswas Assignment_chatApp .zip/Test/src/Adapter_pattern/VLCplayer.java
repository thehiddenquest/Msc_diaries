package Adapter_pattern;

public class VLCplayer implements AdvancedMediaPlayer {
	
	public void playVLC(String filename)
	{
		System.out.println("Playing vlc file :"+filename);
	}
	public void playMP4(String filename)
	{
		
	}

}
