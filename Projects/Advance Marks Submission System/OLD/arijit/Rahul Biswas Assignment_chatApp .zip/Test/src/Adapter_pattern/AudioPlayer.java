package Adapter_pattern;

public class AudioPlayer implements MediaPlayer {
	
	protected MediaAdapter mediaAdapter;
	
	public void play(String type,String filename)
	{
		if(type.equalsIgnoreCase("VLC")|| type.equalsIgnoreCase("MP4"))
		{
			mediaAdapter=new MediaAdapter(type);
			mediaAdapter.play(type, filename);
		}
	}

}
