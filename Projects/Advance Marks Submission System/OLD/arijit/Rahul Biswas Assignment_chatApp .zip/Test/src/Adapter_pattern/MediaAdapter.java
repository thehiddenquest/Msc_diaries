package Adapter_pattern;

public class MediaAdapter implements MediaPlayer {
	
	protected AdvancedMediaPlayer advancedMediaPlayer;
	public MediaAdapter(String type) {
		// TODO Auto-generated constructor stub
		if(type.equalsIgnoreCase("VLC"))
		{
			advancedMediaPlayer=new VLCplayer();
		}
		else if(type.equalsIgnoreCase("Mp4"))
		{
			advancedMediaPlayer=new MP4player();
		}
	}
	
	public void play(String type,String filename)
	{
		if(type.equalsIgnoreCase("VLC"))
		{
			advancedMediaPlayer.playVLC(filename);
		}
		else if(type.equalsIgnoreCase("Mp4"))
		{
			advancedMediaPlayer.playMP4(filename);
		}
	}

}
