package Adapter_pattern;

public interface AdvancedMediaPlayer {
	
	public void playVLC(String filename);
	public void playMP4(String filename);

}
