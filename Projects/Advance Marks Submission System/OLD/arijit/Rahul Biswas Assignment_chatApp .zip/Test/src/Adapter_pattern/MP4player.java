package Adapter_pattern;

public class MP4player implements AdvancedMediaPlayer {
	
	public void playVLC(String filename)
	{
		
	}
	public void playMP4(String filename)
	{
		System.out.println("Playing Mp4 file :"+filename);
	}

}
