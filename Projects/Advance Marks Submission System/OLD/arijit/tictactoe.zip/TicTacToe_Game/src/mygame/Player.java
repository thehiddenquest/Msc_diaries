package mygame;

public class Player {

	public Player() {
		
	}
}
