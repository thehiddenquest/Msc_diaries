package mygame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Game_panel extends JFrame{
	public Game_panel() {
		setTitle("Tic Tac Toe");
		setSize(800,600);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		init_component();
	}
	
	void init_component() {
		JPanel mainPanel = new JPanel();
		mainPanel.setBackground(Color.BLACK);
		mainPanel.setForeground(Color.WHITE);
		
		JPanel keyPanel = new JPanel();
		keyPanel.setBackground(Color.WHITE);
		
		JButton cross = new JButton("Cross");
		cross.setBackground(Color.BLACK);
		JButton circle = new JButton("Circle");
		circle.setBackground(Color.BLACK);
		JButton ok = new JButton("OK");
		ok.setBackground(Color.BLACK);
		
		keyPanel.add(cross);
		keyPanel.add(circle);
		keyPanel.add(ok);
	
		
		add(keyPanel,BorderLayout.SOUTH);
		add(mainPanel,BorderLayout.CENTER);
		
	}
	public static void main(String[] args) {
		Game_panel gp = new Game_panel();
		gp.setVisible(true);
	}

}
