// Student.java
package com.yourcompany.model;

public class Student {
    private int id;
    private String name;
    private String email;

    // Constructors, getters, setters
}
