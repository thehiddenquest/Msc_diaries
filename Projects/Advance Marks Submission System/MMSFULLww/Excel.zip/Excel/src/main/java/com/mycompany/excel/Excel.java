/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.excel;

/**
 *
 * @author Mitu Pradhan
 */
public class Excel {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
