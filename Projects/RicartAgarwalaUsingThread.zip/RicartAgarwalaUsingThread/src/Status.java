public enum Status {
    InCriticalState,
    AfterCriticalState,
    None,
    Requesting
}
