package TheadsCommunication;

public enum MessageType {
    GO_AHEAD,
    DEFERRED,
    HOLD
}
