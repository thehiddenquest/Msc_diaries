package TheadsCommunication;

import java.util.List;
import java.util.Random;

public class Node implements Runnable {
    private String id;
    private String name;
    private Message message;
    private List<Node> nodes;
    private String sendMessage;
    Random random = new Random();

    public Node(String id, String name, Message message, List<Node> nodes) {
        this.id = id;
        this.name = name;
        this.message = message;
        this.nodes = nodes;
    }

    @Override
    public void run() {
        while (true) {
            synchronized (message) {
                String msg = message.getMessage(name);
                if (msg != null) {
                    System.out.println(name + " received: " + msg);
                } else {
                    message.nodeWaiting();
                    int canSend = random.nextInt(2); // 0 or 1
                    if (canSend == 1 || !message.hasPendingMessage()) {
                        createMessage();
                        Node recipient;
                        do {
                            recipient = nodes.get(random.nextInt(nodes.size()));
                        } while (recipient.name.equals(name));

                        message.setMessage(sendMessage, recipient.name);
                        System.out.println(name + " sent: " + sendMessage + " to " + recipient.name);
                    } else {
                        System.out.println(name + ": No Message To Receive");
                    }
                }
            }

            try {
                Thread.sleep(1000); // Random delay between 0 and 999 milliseconds
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private void createMessage() {
        sendMessage = name + " has sent you a message with id: " + id + ". This is my message: " + random.nextInt(20);
    }
}