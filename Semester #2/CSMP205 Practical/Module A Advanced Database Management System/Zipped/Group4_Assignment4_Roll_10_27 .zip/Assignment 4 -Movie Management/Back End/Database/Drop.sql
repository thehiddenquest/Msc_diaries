

drop table movie_director;

drop table movie_actor;

drop table quotes;

-- drop table director_actor;

drop table actor;

drop table director;

drop table movie_genre;

drop table movie;

drop table production_company;

drop table genre;