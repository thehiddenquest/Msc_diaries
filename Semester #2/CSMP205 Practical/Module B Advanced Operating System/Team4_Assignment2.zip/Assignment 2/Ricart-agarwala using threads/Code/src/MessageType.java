public enum MessageType {
    GO_AHEAD,
    REQUEST
}
