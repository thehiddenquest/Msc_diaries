// Acts a process in distributed system 

public class Node {
    int id;
    String nodeName;
    int level;
    int parentId;

    public Node(int id, String nodeName, int level) {
        this.id = id;
        this.nodeName = nodeName;
        this.level = level;
    }

    public int getLevel() {
        return level;
    }

    public int getId() {
        return id;
    }

    public void addParent(int id) {
        this.parentId = id;
    }

    public String getName() {
        return nodeName;
    }

    public Integer getParentId() {
        return parentId;
    }

}
