//Contains the statuses such as pHold, AfterCriticalState, Requesting and None

public enum Status {

}
