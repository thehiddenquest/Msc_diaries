import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Stack;

public class Main {

    public static HashMap<Integer, Node> treeBuilder(String filePath) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;
        int id = 1;
        Stack<Node> precedenceStack = new Stack<>();
        HashMap<Integer, Node> inverseTree = new HashMap<>();
        System.out.println("Print Stack Updates");
        while ((line = reader.readLine()) != null) {
            int level = countLeadingSpaces(line) / 4;
            String nodeName = line.trim();
            Node newNode = new Node(id, nodeName, level);
            if (level == 0) {
                precedenceStack.push(newNode);
            } else {
                while (!precedenceStack.isEmpty()) {
                    Node child = precedenceStack.peek();
                    if (child.getLevel() < level) {
                        child.addParent(newNode.getId());
                        inverseTree.put(child.getId(), child);
                        precedenceStack.pop();
                        System.out.println("child Popped: name : " + child.getName() + " id: " + child.getId()
                                + " parentid: " + child.getParentId());
                    } else {
                        break;
                    }

                }
                precedenceStack.push(newNode);
            }
            id++;
        }
        while (!precedenceStack.isEmpty()) {
            Node node = precedenceStack.pop();
            inverseTree.put(node.getId(), node);
            System.out.println("root Popped: name :" + node.getName() + " id: " + node.getId());
        }
        reader.close();
        return inverseTree;
    }

    public static int countLeadingSpaces(String line) {
        int count = 0;
        while (count < line.length() && line.charAt(count) == ' ') {
            count++;
        }
        return count;
    }

    public static void main(String[] args) {
        try {
            HashMap<Integer, Node> inverseTree = treeBuilder(
                    "F:\\Masters in Computer and Information Science\\CSMC\\Semester #2\\CSMP205 Practical\\Module B Advanced Operating System\\Assignment4\\Input File\\inputFile1.txt");
            System.out.println("Inverse Tree in Hashmap");
            inverseTree.forEach((key, value) -> System.out
                    .println("ID :" + key + " Name :" + value.getName() + " parentId: " + value.getParentId()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
