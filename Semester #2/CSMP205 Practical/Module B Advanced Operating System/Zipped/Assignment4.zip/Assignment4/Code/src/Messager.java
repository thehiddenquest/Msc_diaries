// Maintains the tree structure and is responsible for message passing
public class Messager {

}
