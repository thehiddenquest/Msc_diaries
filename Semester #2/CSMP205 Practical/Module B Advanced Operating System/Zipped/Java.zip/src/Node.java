
// Acts a process in distributed system
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class Node implements Runnable {
    private int id;
    private String nodeName;
    private int level;
    private int parentId;
    private Status status = Status.NONE;
    private Random random = new Random();
    private int i = random.nextInt((30 - 10) + 1) + 10;
    private Queue<String> requestQueue = new LinkedList<>();

    public Node(int id, String nodeName, int level) {
        this.id = id;
        this.nodeName = nodeName;
        this.level = level;
    }

    public int getLevel() {
        return level;
    }

    public int getId() {
        return id;
    }

    public void addParent(int id) {
        this.parentId = id;
    }

    public String getName() {
        return nodeName;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setStatus(Status st) {
        this.status = st;
    }

    @Override
    public void run() {
        try {
            while (!Thread.currentThread().isInterrupted()) {
                System.out.println("Running Node " + nodeName + " with ID: " + id + " Having counter " + i);
                i--;
                if (i <= 0) {
                    Thread.currentThread().interrupt();
                }
            }
            // Implement the logic of your Node's task here
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void requestToken(){
        
    }
    private void SendToken(){
        
    }
    private void receiveToken(){
        
    }
    private void setStatus(){
        if (this.status == Status.NONE) {
            if (random.nextInt(100) < 10) {
                this.setStatus(Status.REQUESTING);
            } else if (random.nextInt(1000) < 5) {
                this.setStatus(Status.ABORT);
            }
        }
    }
    private void checkClock(){
        
    }
}