
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Stack;
import java.util.LinkedList;
import java.util.List;

public class Main {
    public static List<Node> treeBuilder(String filePath) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;
        int id = 1;
        Stack<Node> precedenceStack = new Stack<>();
        List<Node> treeNodes = new LinkedList<>();
        System.out.println("Print Stack Updates");
        while ((line = reader.readLine()) != null) {
            int level = countLeadingSpaces(line) / 4;
            String nodeName = line.trim();
            Node newNode = new Node(id, nodeName, level);
            if (level == 0) {
                precedenceStack.push(newNode);
            } else {
                while (!precedenceStack.isEmpty()) {
                    Node child = precedenceStack.peek();
                    if (child.getLevel() < level) {
                        child.addParent(newNode.getId());
                        // inverseTree.put(child.getId(), child);
                        treeNodes.add(child);
                        precedenceStack.pop();
                        System.out.println("child Popped: name : " + child.getName() + " id: " + child.getId()
                                + " parentid: " + child.getParentId());
                    } else {
                        break;
                    }
                }
                precedenceStack.push(newNode);
            }
            id++;
        }
        int rootCounter = 0;
        while (!precedenceStack.isEmpty()) {
            Node node = precedenceStack.pop();
            // inverseTree.put(node.getId(), node);
            node.setStatus(Status.PHOLD);
            System.out.println("Information Message :: Node " + node.getName() + " with ID "
                    + node.getId() + " have been set to PHOLD Initially.");
            treeNodes.add(node);
            System.out.println("root Popped: name :" + node.getName() + " id: " + node.getId());
            rootCounter++;
        }
        reader.close();
        if (rootCounter != 1) {
            System.out.println("System Message :: Multiple  root found.");
            return null;
        }
        return treeNodes;
    }

    public static int countLeadingSpaces(String line) {
        int count = 0;
        while (count < line.length() && line.charAt(count) == ' ') {
            count++;
        }
        return count;
    }

    public static void main(String[] args) {
        try {
            List<Node> treeNodes = treeBuilder(
                    "inputFile1.txt");
            List<Thread> threads = new LinkedList<>();
            System.out.println("Inverse Tree in LinkedList: ");
            // inverseTree.forEach((key, value) -> System.out
            // .println("ID :" + key + " Name :" + value.getName() + " parentId: " +
            // value.getParentId()));
            if (treeNodes != null) {
                for (Node node : treeNodes) {
                    // Create a new thread for each Node
                    Thread thread = new Thread(node);
                    threads.add(thread);
                    // Start the thread (this will execute the Node's run() method)
                    thread.start();
                }
                // Wait for all threads to finish
                for (Thread thread : threads) {
                    try {
                        thread.join();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println("All threads have finished.");
            }
            // Set the status of the highest level node to PHOLD
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
