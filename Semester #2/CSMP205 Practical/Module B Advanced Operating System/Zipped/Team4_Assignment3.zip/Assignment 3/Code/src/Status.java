public enum Status {
    REQUEST_TOKEN,
    HAVE_TOKEN,
    AFTER_CRITICAL_STATE,
    NONE
}
