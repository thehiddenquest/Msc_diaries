import java.io.*;
import java.util.*;

import javax.swing.JOptionPane;

public class test {
    public static void main(String[] args) {
        Map<String, List<String>> adjacencyList = new HashMap<>();

        try {
            File file = new File("G1");
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.isEmpty()) {
                    continue;
                }

                String[] parts = line.split("->");
                String src = parts[0].trim(); // Source node

                if (parts.length > 1) {
                    for (int i = 1; i < parts.length; i++) {
                        String dest = parts[i].trim(); // Destination node
                        if(dest.equalsIgnoreCase("null"))
                            addEdge(adjacencyList, src, null);
                        else
                            addEdge(adjacencyList, src, dest);

                    }
                } else {
                    addEdge(adjacencyList, src, null); // Handle single node case
                }
            }

            scanner.close();
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + e.getMessage());
        }

        // Printing the adjacency list
        System.out.println("Adjacency List:");
        for (Map.Entry<String, List<String>> entry : adjacencyList.entrySet()) {
            System.out.print(entry.getKey() + " -> ");
            List<String> neighbors = entry.getValue();
            if (!neighbors.isEmpty()) {
                for (int i = 0; i < neighbors.size(); i++) {
                    System.out.print(neighbors.get(i) != null ? (neighbors.get(i).equals("null") ? "null" : neighbors.get(i)) : "NULL");
                    if (i != neighbors.size() - 1) {
                        System.out.print(", ");
                    }
                }
            }
            else{
                System.out.print("null");
            }
            System.out.println();
        }

        // Prompt for initiator input
        String initiator = JOptionPane.showInputDialog("Enter initiator:");
        System.out.println("Initiator entered: " + initiator);
        boolean exists = adjacencyList.keySet().stream().anyMatch(k -> k.equalsIgnoreCase(initiator));
        System.out.println("Initiator exists in the adjacency list (case-insensitive): " + exists);
        System.out.println(adjacencyList.size());
    }

    // Method to add an edge in the adjacency list representation
    private static void addEdge(Map<String, List<String>> adjacencyList, String src, String dest) {
        adjacencyList.putIfAbsent(src, new ArrayList<>());
        if (dest != null) {
            adjacencyList.get(src).add(dest);
        }
    }
    private Boolean BFS(String ini,Map<String, List<String>> adjacencyList) {
		// Number of vertices in the graph
		int noOfNode = adjacencyList.size();
		boolean[] visited = new boolean[noOfNode];
		Arrays.fill(visited, false);
		List<String> q = new ArrayList<>();
		List<String> iniIndex = adjacencyList.get(ini);
		q.add(iniIndex);

		// Set source as visited
		visited[iniIndex] = true;

		int vis;
		while (!q.isEmpty()) {
			vis = q.get(0);
			// Dequeue
			q.remove(0);

			// For every adjacent vertex to the current vertex
			for (int i = 0; i < noOfNode; i++) {
				if (adjacencyMatrix[vis][i] == 1 && !visited[i]) {
					// Enqueue the adjacent node to the queue
					q.add(i);
					visited[i] = true;
				}
			}
		}
		for (int i = 0; i < noOfNode; i++) {
			if (!visited[i]) {
				// If the given vertex is not an initiator return false
				return false;
			}
		}
		// If the given vertex is an initiator return true
		return true;
	}
}