public class HelloWorld {
    StringPrinter sp = new StringPrinter();

    public void print() {
        System.out.println("Hello, World!");
    }

    public void nothing() {
        System.out.println(sp.nothing);
    }
}
