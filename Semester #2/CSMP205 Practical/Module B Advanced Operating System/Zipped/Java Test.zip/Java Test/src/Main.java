/*  To compile this code
create a bin directory 
javac -d bin ./src/*.java 
java -cp bin Main
*/

public class Main {

    public static void main(String[] args) {
        HelloWorld hw = new HelloWorld(); // Create a new instance of the class
        hw.print();
        hw.nothing();
    }
}
