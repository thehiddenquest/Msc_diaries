public class StringPrinter {
    public String nothing = "Nothing new";
}
