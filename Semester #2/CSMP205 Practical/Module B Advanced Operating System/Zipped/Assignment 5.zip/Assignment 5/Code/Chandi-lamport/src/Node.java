import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class Node implements Runnable {
    private String name;
    private Channel channel;
    private List<String> neighbor;
    private Boolean isInitiator = false;
    private Random random = new Random();
    private MessageType messageType;
    private HashMap<String, List<String>> sendMessages;
    private HashMap<String, List<String>> receivedMessages;

    public Node(String name, Channel channel, List<String> neighbor) {
        this.name = name;
        this.channel = channel;
        this.neighbor = neighbor;
    }

    @Override
    public synchronized void run() {
        while (!Thread.currentThread().isInterrupted()) {

        }
        System.out.println("Node " + name + " is running on channel having");
    }

    public void setInitiatorStatus() {
        isInitiator = true;
    }

    public HashMap<String, List<String>> getSendMessages() {
        return sendMessages;
    }

    public HashMap<String, List<String>> getReceivedMessages() {
        return receivedMessages;
    }

    public String getName() {
        return name;
    }

    private void sendMessage() {
        if (messageType == MessageType.MARKER) {
            for (String receiverName : neighbor) {
                String message = messageGenarator(null, receiverName);
                channel.deliver(message);
            }
        } else {
            int randomIndex = random.nextInt(neighbor.size());
            // Get the element at the random index
            String receiverName = neighbor.get(randomIndex);
            String messageContent = String.valueOf(random.nextInt(100));
            String message = messageGenarator(messageContent, receiverName);
            boolean exists = sendMessages.keySet().stream().anyMatch(k -> k.equalsIgnoreCase(receiverName));
            if (exists) {
                List<String> temp = sendMessages.get(receiverName);
                temp.add(messageContent);
                sendMessages.put(receiverName, temp);
            } else {
                List<String> temp = new LinkedList<>();
                temp.add(messageContent);
                sendMessages.put(receiverName, temp);
            }
            channel.deliver(message);
        }
    }

    private void receivedMessage() {

    }

    private void messageTypeChooser() {
        int chooser = random.nextInt(10);
        if (chooser < 6)
            messageType = MessageType.TEXT;
        else
            messageType = MessageType.MARKER;
    }

    private String messageGenarator(String messageContent, String receiverName) {
        String message;
        message = name + ":" + messageType + ":" + messageContent + ":" + receiverName;
        return message;
    }
}
