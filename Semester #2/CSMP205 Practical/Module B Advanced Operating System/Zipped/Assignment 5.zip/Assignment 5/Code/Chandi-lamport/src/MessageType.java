public enum MessageType {
    TEXT,
    MARKER
}
