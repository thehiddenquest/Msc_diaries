package ricart_agarwala;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		RicartAgarwala m = new RicartAgarwala();
		m.run();
	}
}

class RicartAgarwala {
	private HashMap<String, Node> nameToObject = new HashMap<>();
	private int clock = 1;

	public void run() {
		input();
		nodesWantToEnterCS();
		requestingCS();
	}

	public void input() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of nodes:");
		int numOfNodes = Integer.parseInt(sc.nextLine());
		for (int i = 1; i <= numOfNodes; i++) {
			Node n = new Node();
			n.setUID(i);
			System.out.println("Enter Name for node " + i + ":");
			String name = sc.nextLine().trim();
			n.setName(name);
			nameToObject.put(name, n);
		}
	}

	public void nodesWantToEnterCS() {
		Scanner sc = new Scanner(System.in);
		System.out.println("How many nodes want to enter the Critical section:");
		int counter = Integer.parseInt(sc.nextLine());
		for (int i = 1; i <= counter; i++) {
			System.out.println("Enter name of the node:");
			String name = sc.nextLine();
			Node n = nameToObject.get(name);
			if (n != null) {
				n.setTimestamp(clock);
				clock++;
				n.setStatus(1);
			}
		}
		for (Entry<String, Node> entry : nameToObject.entrySet()) {
			Node n = entry.getValue();
			System.out.println("Name: " + entry.getKey() + ", UID: " + n.getUID() + ", Timestamp: " + n.getTimestamp()
					+ ", Status: " + n.getStatus());
		}
	}

	public void requestingCS() {
		for (Entry<String, Node> entry : nameToObject.entrySet()) {
			if (entry.getValue().getStatus() == 1) {
				for (Entry<String, Node> entry1 : nameToObject.entrySet()) {
					if (!entry1.getValue().getName().equals(entry.getValue().getName())) {
						entry.getValue().requestList.add(entry1.getValue().getName());
					}
				}
			}
		}
		
		for (Entry<String, Node> entry : nameToObject.entrySet()) {
			if (entry.getValue().getStatus() == 1) {
				for (Entry<String, Node> entry1 : nameToObject.entrySet()) {
					if (!entry1.getValue().getName().equals(entry.getValue().getName())) {
						entry1.getValue().requestFrom(entry.getValue());
					}
				}
			}
		}
		
	}
}