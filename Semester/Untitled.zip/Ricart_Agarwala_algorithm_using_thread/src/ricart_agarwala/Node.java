package ricart_agarwala;

public class Node implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

}
